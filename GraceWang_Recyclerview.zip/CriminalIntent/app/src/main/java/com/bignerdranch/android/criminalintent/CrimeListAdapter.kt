package com.bignerdranch.android.criminalintent

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bignerdranch.android.criminalintent.databinding.ListItemCrimeBinding
import com.bignerdranch.android.criminalintent.databinding.ListItemReqpoliceCrimeBinding

class CrimeListAdapter(private val crimes: List<Crime>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val VIEW_TYPE_NORMAL = 0
        private const val VIEW_TYPE_POLICE = 1
    }

    override fun getItemViewType(position: Int): Int =
        if (crimes[position].requiresPolice) VIEW_TYPE_POLICE else VIEW_TYPE_NORMAL

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            VIEW_TYPE_POLICE -> {
                val binding = ListItemReqpoliceCrimeBinding.inflate(layoutInflater, parent, false)
                CrimePoliceHolder(binding)
            }
            else -> {
                val binding = ListItemCrimeBinding.inflate(layoutInflater, parent, false)
                CrimeHolder(binding)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is CrimeHolder -> holder.bind(crimes[position])
            is CrimePoliceHolder -> holder.bind(crimes[position])
        }
    }

    override fun getItemCount(): Int = crimes.size

    // ViewHolder for normal crimes
    inner class CrimeHolder(private val binding: ListItemCrimeBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(crime: Crime) {
            with(binding) {
                crimeTitle.text = crime.title
                crimeDate.text = crime.date.toString()
            }
        }
    }

    // ViewHolder for crimes that require police intervention
    inner class CrimePoliceHolder(private val binding: ListItemReqpoliceCrimeBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(crime: Crime) {
            with(binding) {
                crimeTitle.text = "${crime.title} requires police!"
                crimeDate.text = crime.date.toString()
            }
        }
    }
}

